# My Student Profile

Name: Poramet Poksuk
Student ID: 67111311
Major: Computer Engineering
Goal: learn how to use Git
Favorite topic: AHHHHHHHH