# My Study Plan

Javascript เพราะ อยากเอาไว้ใช้คู่กับเอไอในการสร้างเว็บจะได้สะดวกขึ้น
Practic: ดูคลิปที่สอนแล้วลองทำตาม 

css เพราะ เหตุผลเหมือนกันกับ Javascript
Practic: เหมือนกับของ Javascript 

AI-Agent เพราะ อยากใช้ AI ให้ดีที่สุด ให้ดีกว่านี้git add study-plan.md
Practic: ฝึก prompt ให้มีความถูกต้องและแม่นยำ ตามที่เราต้องการ